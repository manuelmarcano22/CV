# LaTeX Curriculum Vitae

 LaTeX Curriculum Vitae Template from 
 Copyright (C) 2004-2009 Jason Blevins <jrblevin@sdf.lonestar.org>
http://jblevins.org/projects/cv-template/

